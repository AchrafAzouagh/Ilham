import './App.css';
import Form from './Form';

function App() {
  return (
    <div className="App">
      <main className="App-main">
        <Form />
      </main>
    </div>
  );
}

export default App;
